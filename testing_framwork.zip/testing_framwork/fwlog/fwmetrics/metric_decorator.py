#
#   This describe the decorator needed to invoke the metric capture when doing performance and load testing
#
from functools import wraps


def fw_metric(func):
    @wraps(func)
    def wrapped(*args, **kwargs):
        #
        # pre-method operation
        #
        print("Before " + str(func))
        #
        r = func(*args, **kwargs)
        #
        # post-method operation
        #
        print("After " + str(func))
        #
        return r
    return wrapped


