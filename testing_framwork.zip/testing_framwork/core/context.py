


class Context:
    def __init__(self):
        self.version = 2.12
        self.server_ip = "192.168.0.1"
        selft.server_port = ""

        pass




