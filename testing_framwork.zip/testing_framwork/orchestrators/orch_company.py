#
#
#
from testing_framwork.orchestrators import i_orchetrator


class OrchestratorCompany(i_orchetrator.IOrchestrator):

    def run(self):
        pass

    def pause(self):
        pass