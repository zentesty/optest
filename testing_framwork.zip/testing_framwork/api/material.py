#
#
#
from testing_framwork.api import iapi


class Material(iapi.ICallable):

    def create(self):
        pass

    def delete(self):
        pass

    def update(self):
        pass

    def search(self):
        pass